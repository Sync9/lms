package sync9.lms.uil;

import io.tomo.lms.exception.UserNotFoundException;

public interface UILogic {
    void init() ;
}
