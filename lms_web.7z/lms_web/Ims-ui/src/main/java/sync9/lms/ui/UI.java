package sync9.lms.ui;

import io.tomo.lms.entity.User;

public interface UI {
    void displayBookCirculationUI(User user);
    void displayUserManagementUI(User user);
    void displayBookManagementUI(User user);
    void displayBookQueryUI(User user);
    void displayMainUI(User user);
}
