package sync9.lms.ui.impl;

import io.tomo.lms.entity.User;
import sync9.lms.ui.UI;

public class UiImpl implements UI {

    @Override
    public void displayUserManagementUI(User user) {
        System.out.println("\t**************************************");
        if(user.getType()==3) System.out.println("\t\t1. 用户信息录入\n\t\t2. 用户信息修改\n\t\t3. 用户信息删除\n\t\t4. 用户信息查询\n\t\t5. 用户密码修改");
        else System.out.println("\t\t1. 用户密码修改");
        System.out.println("\t\t0. 返回主菜单\n\t**************************************");
    }

    @Override
    public void displayBookManagementUI(User user){
        System.out.println("\t**************************************");
        if(user.getType()==2) System.out.println("\t\t1. 图书信息录入\n\t\t2. 图书信息修改\n\t\t3. 图书信息删除\n\t\t4. 图书信息查询");
        else System.out.println("\t\t1. 图书信息查询");
        System.out.println("\t\t0. 返回主菜单\n\t**************************************");
    }

    @Override
    public void displayBookQueryUI(User user){
        System.out.println("\t**************************************\n\t\t1. 按书号查询\n\t\t2. 按书名查询\n\t\t3. 按作者查询\n\t\t0. 返回主菜单\n\t**************************************");
    }

    @Override
    public void displayMainUI(User user){
        System.out.println("\t**************************************\n\t\t1. 用户管理\n\t\t2. 图书管理");
        if(user.getType()==2) System.out.println("\t\t3. 图书流通管理");
        System.out.println("\t\t0. 退出系统\n\t**************************************");
    }

    @Override
    public void displayBookCirculationUI(User user){
        System.out.println("\t**************************************\n\t\t1. 借书处理\n\t\t2. 还书处理\n\t\t3. 借阅信息查询\n\t\t0. 返回主菜单\n\t**************************************");
    }
}
