package sync9.lms.uil.impl;
import io.tomo.lms.entity.Book;
import io.tomo.lms.entity.List;
import io.tomo.lms.entity.User;
import io.tomo.lms.exception.BookNotFoundException;
import io.tomo.lms.exception.TableNotFoundException;
import io.tomo.lms.exception.UserNotFoundException;
import io.tomo.lms.exception.UsernameExistException;
import io.tomo.lms.service.BookService;
import io.tomo.lms.service.ListService;
import io.tomo.lms.service.UserService;
import io.tomo.lms.service.impl.ListServiceImpl;
import io.tomo.lms.service.impl.UserServiceImpl;
import sync9.lms.ui.UI;
import sync9.lms.uil.UILogic;

import javax.swing.plaf.ListUI;
import java.util.Iterator;
import java.util.Scanner;

public class InitImpl implements UILogic {
    private User user;
    private List tmpList;
    private Book tmpBook;
    private User tmpUser;
    private UserService userService;
    private ListService listService;
    private BookService bookServices;
    private UI ui;
    public void init() {
        Scanner sc=new Scanner(System.in);
        int cnt=0;
        while(cnt!=3){
            System.out.println("Please input your id");
            String id=sc.next();
            System.out.println("Please input your password");
            String password=sc.next();
            try{
                user=userService.login(id, password);
            }catch (UserNotFoundException e){
                user=null;
                System.out.println("User Not Found");
            }
            if(user!=null) break;
            else{
                System.out.println("Please try again");
            }
            cnt++;
        }
        if(cnt==3) {
            System.out.println("You have tried 3 times\nSystem will exit");
            System.exit(-1);
        }
        int select=-1;
        while(select!=0){
            ui.displayMainUI(user);
            select=sc.nextInt();
            judgeCaseForTheMainMenu(select);
        }
        sc.close();
    }
    private void judgeCaseForTheMainMenu(int select){
        Scanner sc=new Scanner(System.in);
        if(select==1){
            while(select!=0){
                ui.displayUserManagementUI(user);
                select=sc.nextInt();
                judgeCaseForTheUserManagementMenu(select);
            }
        }
        else if(select==2){
            while(select!=0){
                ui.displayBookManagementUI(user);
                select=sc.nextInt();
                judgeCaseForTheBookManagement(select);
            }
        }
        else if(select==3&&user.getType()==2){
            while(select!=0){
                ui.displayBookCirculationUI(user);
                select=sc.nextInt();
                judgeCaseForTheLendReturnManagement(select);
            }
        }
        else if(select==0){
            sc.close();
        }else {
            System.out.println("Invalid Input\nTry Again");
        }
    }
    private void judgeCaseForTheUserManagementMenu(int select){
        Scanner sc=new Scanner(System.in);
        if(user.getType()==1||user.getType()==2){
            if(select==1){
                tmpUser.setId(user.getId());
                tmpUser.setPwd(sc.nextLine());
                try{userService.modify(tmpUser);}
                catch (UserNotFoundException e){
                    System.out.println("User Not Found\n" + "Fail To Change Password");
                }
            }
            else if(select==0){
                sc.close();
            }
            else{
                System.out.println("Invalid Input");
            }
        }
        else{
            if(select==1){
                inputUserInfo(sc);
                try {
                    userService.add(tmpUser);
                }catch (UsernameExistException e){
                    System.out.println("The user has exist");
                }
            }
            else if(select==2){
                inputUserInfo(sc);
                try {
                    userService.modify(tmpUser);
                }catch (UserNotFoundException e){
                    System.out.println("User Not Found\n"+"Fail to Modify User Info");
                }
            }
            else if(select==3){
                System.out.println("Please input the id you are going to delete");
                try {
                    userService.removeById(sc.nextLine());
                }catch (UserNotFoundException e){
                    System.out.println("User Not Found\n" + "Fail To Delete User Info");
                }
            }
            else if(select==4){
                Iterator<User> it= userService.findAll().listIterator();
                System.out.println(it.next());
            }
            else if(select==5){
                tmpUser.setId(user.getId());
                tmpUser.setPwd(sc.nextLine());
                try{userService.modify(tmpUser);}
                catch (UserNotFoundException e){
                    System.out.println("User Not Found\n" + "Fail To Change Password");
                }
            }
            else if(select==0){
                sc.close();
            }
            else{
                System.out.println("Invalid Input");
            }
        }
    }

    private void inputUserInfo(Scanner sc) {
        System.out.println("Please input the user info");
        System.out.println("Please input the ID");
        tmpUser.setId(sc.nextLine());
        System.out.println("Please input the user's name");
        tmpUser.setName(sc.nextLine());
        System.out.println("Please input the user's password");
        tmpUser.setPwd(sc.nextLine());
        System.out.println("Please input the user's telephone");
        tmpUser.setTelephone(sc.nextLine());
        System.out.println("Please input where the user work at");
        tmpUser.setUnit(sc.nextLine());
        System.out.println("How many book the user can borrow");
        tmpUser.setCount(sc.nextInt());
        System.out.println("Please input the user's type");
        System.out.println("1 is for reader");
        System.out.println("2 is for library administrator");
        System.out.println("3 is for system administrator");
        tmpUser.setType(sc.nextInt());
    }

    private void inputBookInfo(Scanner sc){
        System.out.println("Please input the book info");
        System.out.println("Please input the No");
        tmpBook.setNo(sc.nextInt());
        System.out.println("Please input the book's name");
        tmpBook.setName(sc.nextLine());
        System.out.println("Please input the book's author");
        tmpBook.setAuthor(sc.nextLine());
        System.out.println("Please input the book's press");
        tmpBook.setPress(sc.nextLine());
        System.out.println("How many the book in the library");
        tmpBook.setCount(sc.nextInt());
    }
    private void judgeCaseForTheBookManagement(int select){
        int selection_internal=-1;
        Scanner sc=new Scanner(System.in);
        if(user.getType()==1||user.getType()==3){
            if(select==1){
                while(selection_internal!=0){
                    ui.displayBookQueryUI(user);
                    selection_internal=sc.nextInt();
                    judgeCaseForTheBookInformationQuery(selection_internal);
                }
            }
            else if(select==0);
            else{
                System.out.println("Invalid Input");
            }
        }
        else{
            if(select==1){
                inputBookInfo(sc);
                bookServices.add(tmpBook);
            }
            else if(select==2){
                inputBookInfo(sc);
                try{
                    bookServices.modify(tmpBook);
                }catch (BookNotFoundException e){
                    System.out.println("Book Not Found\n" + "Fail To Modify Book");
                }
            }
            else if(select==3){
                System.out.println("Please input the book no you are going to delete");
                try {
                    bookServices.removeByNo(sc.nextInt());
                }catch (BookNotFoundException e){
                    System.out.println("Book Not Found\n" + "Fail To Delete Book Info");
                }
            }
            else if(select==4){
                while(selection_internal!=0){
                    ui.displayBookQueryUI(user);
                    selection_internal=sc.nextInt();
                    judgeCaseForTheBookInformationQuery(selection_internal);
                }
            }
            else if(select==0);
            else{
                System.out.println("Invalid Input");
            }
        }
    }
    private void judgeCaseForTheLendReturnManagement(int select){
        Scanner sc=new Scanner(System.in);
        if(select==1){
                System.out.println("Please input the user's id, book's no and operation");
                try {
                    listService.lendBook(sc.nextLine(), sc.nextInt(), sc.nextLine());
                }catch (BookNotFoundException e){
                    System.out.println("Book Not Found");
                }
                catch (UserNotFoundException e){
                    System.out.println("User Not Found");
                }
        }
        else if(select==2){
            System.out.println("Please input the serialNo");
            try {
                listService.returnBack(sc.nextInt());
            }catch (TableNotFoundException e){
                System.out.println("Table Not Found");

            }catch (BookNotFoundException e){
                System.out.println("Book Not Found");
            }
        }
        else if(select==3){
            System.out.println("Please input the No no you are going to query");
            try {
                listService.findNo(sc.nextInt());
            }catch (TableNotFoundException e){
                System.out.println("Table Not Found\n" + "Fail To Query Info");
            }
        }
        else if(select==0);
        else{
            System.out.println("Invalid Input");
        }
    }
    private void judgeCaseForTheBookInformationQuery(int select){
        Scanner sc=new Scanner(System.in);
        if(select==1){
            try{
                bookServices.findById(sc.nextInt());
            }catch (BookNotFoundException e){
                System.out.println("Book Not Found\n" + "Fail To Query Book Info");
            }
        }
        else if(select==2){
            try{
                bookServices.findByName(sc.nextLine());
            }catch (BookNotFoundException e){
                System.out.println("Book Not Found\n" + "Fail To Query Book Info");
            }
        }
        else if(select==3){
            try{
                bookServices.findByAuthor(sc.nextLine());
            }catch (BookNotFoundException e){
                System.out.println("Book Not Found\n" + "Fail To Query Book Info");
            }
        }
        else if(select==0);
        else{
            System.out.println("Invalid Input");
        }
    }
}
